package thegenuinegourav.voicemail;

public class Config {
    public static  String EMAIL ="";  //gmail address
    public static  String PASSWORD =""; //password
}
